import { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { Patient, Appointment, BillingInvoice, Prescription, SyncStatus, IndoorAdmission, GlobalSettings, StaffMember, StaffTransaction } from './types';
import { initAuth, logout, writeSheetData } from './firebase';
import Dashboard from './components/Dashboard';
import PatientManagement from './components/PatientManagement';
import AppointmentManagement from './components/AppointmentManagement';
import BillingManagement from './components/BillingManagement';
import PrescriptionGenerator from './components/PrescriptionGenerator';
import SheetsSync from './components/SheetsSync';
import IndoorAdmissionComponent from './components/IndoorAdmission';
import SettingsManagement from './components/SettingsManagement';
import StaffPayrollManagement from './components/StaffPayrollManagement';
import { Activity, Users, Calendar, Receipt, Clipboard, Database, Heart, RefreshCw, LogOut, CheckCircle2, Hospital, Settings } from 'lucide-react';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState('dashboard');

  // Firebase Auth states
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);

  // Core Data States
  const [patients, setPatients] = useState<Patient[]>(() => {
    const saved = localStorage.getItem('hms_patients');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    const saved = localStorage.getItem('hms_appointments');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [invoices, setInvoices] = useState<BillingInvoice[]>(() => {
    const saved = localStorage.getItem('hms_invoices');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(() => {
    const saved = localStorage.getItem('hms_prescriptions');
    return saved ? JSON.parse(saved) : [];
  });

  const [admissions, setAdmissions] = useState<IndoorAdmission[]>(() => {
    const saved = localStorage.getItem('hms_admissions');
    return saved ? JSON.parse(saved) : [];
  });

  // Google Sheets Sync state
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(() => {
    const savedId = localStorage.getItem('hms_spreadsheet_id');
    const savedUrl = localStorage.getItem('hms_spreadsheet_url');
    return {
      spreadsheetId: savedId || null,
      spreadsheetUrl: savedUrl || null,
      lastSynced: localStorage.getItem('hms_last_synced') || null,
      isSyncing: false,
      error: null,
    };
  });

  // Direct patient action from list to sub-tabs
  const [directPatient, setDirectPatient] = useState<Patient | null>(null);

  // Persistence hooks
  useEffect(() => {
    localStorage.setItem('hms_patients', JSON.stringify(patients));
  }, [patients]);

  useEffect(() => {
    localStorage.setItem('hms_appointments', JSON.stringify(appointments));
  }, [appointments]);

  useEffect(() => {
    localStorage.setItem('hms_invoices', JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem('hms_prescriptions', JSON.stringify(prescriptions));
  }, [prescriptions]);

  useEffect(() => {
    localStorage.setItem('hms_admissions', JSON.stringify(admissions));
  }, [admissions]);

  // Global settings state
  const [globalSettings, setGlobalSettings] = useState<GlobalSettings>(() => {
    const saved = localStorage.getItem('hms_global_settings');
    return saved ? JSON.parse(saved) : {
      institutionName: 'ডাঃ জসিম মুকুল হাসপাতাল',
      englishName: 'DR. JASIM MUKUL HOSPITAL',
      phone: '০১৭৫০০০০০০০',
      address: '২১৪/১ ভি আই পি রোড, গলাচিপা, পটুয়াখালী',
      selectedFont: 'Hind Siliguri',
      fontSizeMultiplier: 'Normal',
      defaultAdmissionFee: 500,
      defaultDoctorFee: 400
    };
  });

  useEffect(() => {
    localStorage.setItem('hms_global_settings', JSON.stringify(globalSettings));
  }, [globalSettings]);

  // Dynamic test rates state
  const [diagnosticTests, setDiagnosticTests] = useState<{ name: string; cost: number; category: string }[]>(() => {
    const saved = localStorage.getItem('hms_diagnostic_tests');
    if (saved) return JSON.parse(saved);
    return [
      { name: '(CBC). ESR', cost: 400, category: 'HAEMATOLOGY' },
      { name: 'CBC with ESR (CC)', cost: 600, category: 'HAEMATOLOGY' },
      { name: 'TC.DC', cost: 250, category: 'HAEMATOLOGY' },
      { name: 'HB%', cost: 250, category: 'HAEMATOLOGY' },
      { name: 'ESR', cost: 200, category: 'HAEMATOLOGY' },
      { name: 'Platelet Count', cost: 300, category: 'HAEMATOLOGY' },
      { name: 'MP', cost: 200, category: 'HAEMATOLOGY' },
      { name: 'BT/CT', cost: 350, category: 'HAEMATOLOGY' },
      { name: 'C/E Count', cost: 250, category: 'HAEMATOLOGY' },
      { name: 'T3', cost: 1200, category: 'HORMONE PANEL' },
      { name: 'T4', cost: 1200, category: 'HORMONE PANEL' },
      { name: 'FT3', cost: 900, category: 'HORMONE PANEL' },
      { name: 'FT4', cost: 900, category: 'HORMONE PANEL' },
      { name: 'TSH', cost: 1100, category: 'HORMONE PANEL' },
      { name: 'HbA1c', cost: 1500, category: 'HORMONE PANEL' },
      { name: 'Prolactin', cost: 1200, category: 'HORMONE PANEL' },
      { name: 'S, IgE', cost: 1500, category: 'HORMONE PANEL' },
      { name: 'S,IgE (Device Test)', cost: 700, category: 'HORMONE PANEL' },
      { name: 'Widal', cost: 450, category: 'SEROLOGY' },
      { name: 'Aso Titre', cost: 450, category: 'SEROLOGY' },
      { name: 'CRP', cost: 450, category: 'SEROLOGY' },
      { name: 'RA/RF', cost: 450, category: 'SEROLOGY' },
      { name: 'HBs Ag (Screen Test)', cost: 450, category: 'SEROLOGY' },
      { name: 'TPHA', cost: 450, category: 'SEROLOGY' },
      { name: 'VDRL', cost: 400, category: 'SEROLOGY' },
      { name: 'Group & Rh Factor', cost: 200, category: 'SEROLOGY' },
      { name: 'Mantaux-Test (M.T)', cost: 300, category: 'SEROLOGY' },
      { name: 'Triple Antigen', cost: 350, category: 'SEROLOGY' },
      { name: 'R.Fever', cost: 300, category: 'SEROLOGY' },
      { name: 'HIV', cost: 500, category: 'SEROLOGY' },
      { name: 'HCV', cost: 800, category: 'SEROLOGY' },
      { name: 'TB (ICT)', cost: 750, category: 'SEROLOGY' },
      { name: 'Malaria. pf/pv', cost: 700, category: 'SEROLOGY' },
      { name: 'H. Pylori', cost: 850, category: 'SEROLOGY' },
      { name: 'Filaria (ICT)', cost: 750, category: 'SEROLOGY' },
      { name: 'Dengue NS1. IGG/IGM', cost: 300, category: 'SEROLOGY' },
      { name: 'Random', cost: 200, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'Fasting', cost: 200, category: 'BIO CHEMICAL ANALYSIS' },
      { name: '2hr. After Breakfast', cost: 200, category: 'BIO CHEMICAL ANALYSIS' },
      { name: '2hr. After 75gm Glucose', cost: 200, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'O.G,T.T', cost: 500, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'Blood Urea', cost: 400, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'Cholesterol', cost: 350, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'HDL', cost: 400, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'TG', cost: 350, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'LDL', cost: 300, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'S,GPT(ALT)', cost: 500, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'S,GOT(AST)', cost: 500, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'Bilirubin Total', cost: 350, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'Lipid Profile', cost: 1000, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'Bilirubin Direct/indirect', cost: 450, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'Serum Creatinine', cost: 400, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'Uric Acid', cost: 400, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'Amylase', cost: 700, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'Calcium', cost: 600, category: 'BIO CHEMICAL ANALYSIS' },
      { name: 'Chest X-Ray', cost: 500, category: 'X-RAY DIGITAL' },
      { name: 'PNS X-Ray', cost: 500, category: 'X-RAY DIGITAL' },
      { name: 'Maxilla X-Ray', cost: 500, category: 'X-RAY DIGITAL' },
      { name: 'Nasopharynx X-Ray', cost: 550, category: 'X-RAY DIGITAL' },
      { name: 'Abdomen A/P X-Ray', cost: 500, category: 'X-RAY DIGITAL' },
      { name: 'Cervical Spine X-Ray', cost: 600, category: 'X-RAY DIGITAL' },
      { name: 'Plane X-Ray Abdomen', cost: 500, category: 'X-RAY DIGITAL' },
      { name: 'Mastoid Towns View X-Ray', cost: 500, category: 'X-RAY DIGITAL' },
      { name: 'Skull X-Ray', cost: 600, category: 'X-RAY DIGITAL' },
      { name: 'Pelvic X-Ray', cost: 500, category: 'X-RAY DIGITAL' },
      { name: 'Mandible B/V X-Ray', cost: 600, category: 'X-RAY DIGITAL' },
      { name: 'KUB X-Ray', cost: 500, category: 'X-RAY DIGITAL' },
      { name: 'D/S Spine X-Ray', cost: 600, category: 'X-RAY DIGITAL' },
      { name: 'L/S Spine X-Ray', cost: 600, category: 'X-RAY DIGITAL' },
      { name: 'X-ray Foot B/V', cost: 500, category: 'X-RAY DIGITAL' },
      { name: 'Knee B/V X-Ray', cost: 550, category: 'X-RAY DIGITAL' },
      { name: 'Elbow B/V X-Ray', cost: 500, category: 'X-RAY DIGITAL' },
      { name: 'Shoulder Joint B/V X-Ray', cost: 550, category: 'X-RAY DIGITAL' },
      { name: 'Hip Joint X-Ray', cost: 500, category: 'X-RAY DIGITAL' },
      { name: 'Urine Pregnancy Test (PT)', cost: 200, category: 'URINE EXAM' },
      { name: 'Urine R/E', cost: 250, category: 'URINE EXAM' },
      { name: 'Stool R/E', cost: 400, category: 'STOOL EXAM' },
      { name: 'Stool OBT', cost: 400, category: 'STOOL EXAM' },
      { name: 'USG Whole Abdomen', cost: 1000, category: 'ULTRASOUND IMAGING' },
      { name: 'USG Upper Abdomen', cost: 800, category: 'ULTRASOUND IMAGING' },
      { name: 'USG Lower Abdomen', cost: 800, category: 'ULTRASOUND IMAGING' },
      { name: 'USG KUB', cost: 1000, category: 'ULTRASOUND IMAGING' },
      { name: 'USG Pregnancy Profile', cost: 800, category: 'ULTRASOUND IMAGING' },
      { name: 'USG Breast', cost: 1200, category: 'ULTRASOUND IMAGING' },
      { name: 'USG color doppler', cost: 1500, category: 'ULTRASOUND IMAGING' }
    ];
  });

  useEffect(() => {
    localStorage.setItem('hms_diagnostic_tests', JSON.stringify(diagnosticTests));
  }, [diagnosticTests]);

  // Staff and Payroll states
  const [staff, setStaff] = useState<StaffMember[]>(() => {
    const saved = localStorage.getItem('hms_staff_list');
    return saved ? JSON.parse(saved) : [];
  });

  const [staffTransactions, setStaffTransactions] = useState<StaffTransaction[]>(() => {
    const saved = localStorage.getItem('hms_staff_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('hms_staff_list', JSON.stringify(staff));
  }, [staff]);

  useEffect(() => {
    localStorage.setItem('hms_staff_transactions', JSON.stringify(staffTransactions));
  }, [staffTransactions]);

  // Handle Firebase Auth initialized state on mount
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, accessToken) => {
        setUser(currentUser);
        setToken(accessToken);
      },
      () => {
        // No cached token/not logged in
        setUser(null);
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleLoginSuccess = (currentUser: User, accessToken: string) => {
    setUser(currentUser);
    setToken(accessToken);
  };

  const handleLogout = async () => {
    await logout();
    setUser(null);
    setToken(null);
  };

  // 1. Patient actions
  const handleAddPatient = (newPatient: Omit<Patient, 'id' | 'createdAt'>) => {
    const patientWithId: Patient = {
      ...newPatient,
      id: Math.random().toString(36).substring(2, 11).toUpperCase(),
      createdAt: new Date().toISOString(),
    };
    setPatients(prev => [...prev, patientWithId]);
    return patientWithId;
  };

  const handleUpdatePatient = (updatedPatient: Patient) => {
    setPatients(prev => prev.map(p => (p.id === updatedPatient.id ? updatedPatient : p)));
  };

  const handleDeletePatient = (id: string) => {
    setPatients(prev => prev.filter(p => p.id !== id));
    // Cascade deletions for appointments, prescriptions & bills to keep data clean
    setAppointments(prev => prev.filter(a => a.patientId !== id));
    setInvoices(prev => prev.filter(i => i.patientId !== id));
    setPrescriptions(prev => prev.filter(p => p.patientId !== id));
  };

  // 2. Appointment actions
  const handleAddAppointment = (newApp: Omit<Appointment, 'id' | 'serialNo'>) => {
    // Calculate serial number for this doctor on this date
    const dailyDoctorApps = appointments.filter(a => a.doctorName === newApp.doctorName && a.date === newApp.date);
    const nextSerial = dailyDoctorApps.length + 1;

    const appointmentWithId: Appointment = {
      ...newApp,
      id: Math.random().toString(36).substring(2, 11).toUpperCase(),
      serialNo: nextSerial,
    };
    setAppointments(prev => [...prev, appointmentWithId]);
  };

  const handleUpdateAppointmentStatus = (id: string, status: 'Pending' | 'Completed' | 'Cancelled') => {
    setAppointments(prev => prev.map(app => (app.id === id ? { ...app, status } : app)));
  };

  // 3. Billing actions
  const handleAddInvoice = (newInvoice: Omit<BillingInvoice, 'id' | 'createdAt'>) => {
    const invoiceWithId: BillingInvoice = {
      ...newInvoice,
      id: Math.random().toString(36).substring(2, 11).toUpperCase(),
      createdAt: new Date().toISOString(),
    };
    setInvoices(prev => [...prev, invoiceWithId]);
  };

  const handleUpdatePayment = (id: string, newAmountPaid: number) => {
    setInvoices(prev => prev.map(inv => {
      if (inv.id === id) {
        const remainingDue = Math.max(0, inv.total - newAmountPaid);
        return {
          ...inv,
          amountPaid: newAmountPaid,
          dueAmount: remainingDue,
          status: remainingDue === 0 ? 'Paid' : 'Partial' as any,
        };
      }
      return inv;
    }));
  };

  // 4. Prescription actions
  const handleAddPrescription = (newPres: Omit<Prescription, 'id' | 'createdAt'>) => {
    const presWithId: Prescription = {
      ...newPres,
      id: Math.random().toString(36).substring(2, 11).toUpperCase(),
      createdAt: new Date().toISOString(),
    };
    setPrescriptions(prev => [...prev, presWithId]);
  };

  // 4b. Indoor Admission actions
  const handleAddAdmission = (newAdm: Omit<IndoorAdmission, 'id' | 'createdAt'>) => {
    const admWithId: IndoorAdmission = {
      ...newAdm,
      id: Math.random().toString(36).substring(2, 11).toUpperCase(),
      status: newAdm.status || 'Admitted',
      createdAt: new Date().toISOString(),
    };
    setAdmissions(prev => [...prev, admWithId]);
  };

  const handleUpdateAdmission = (updatedAdm: IndoorAdmission) => {
    setAdmissions(prev => prev.map(a => (a.id === updatedAdm.id ? updatedAdm : a)));
  };

  const handleDeleteAdmission = (id: string) => {
    setAdmissions(prev => prev.filter(a => a.id !== id));
  };

  const handleUpdateCommissionStatus = (id: string, newStatus: 'Paid' | 'Unpaid') => {
    setInvoices(prev => prev.map(inv => (inv.id === id ? { ...inv, commissionPaidStatus: newStatus } : inv)));
  };

  const handleRestoreData = (backup: any) => {
    if (!backup) return;
    if (backup.patients) {
      setPatients(backup.patients);
      localStorage.setItem('hms_patients', JSON.stringify(backup.patients));
    }
    if (backup.appointments) {
      setAppointments(backup.appointments);
      localStorage.setItem('hms_appointments', JSON.stringify(backup.appointments));
    }
    if (backup.invoices) {
      setInvoices(backup.invoices);
      localStorage.setItem('hms_invoices', JSON.stringify(backup.invoices));
    }
    if (backup.prescriptions) {
      setPrescriptions(backup.prescriptions);
      localStorage.setItem('hms_prescriptions', JSON.stringify(backup.prescriptions));
    }
    if (backup.admissions) {
      setAdmissions(backup.admissions);
      localStorage.setItem('hms_admissions', JSON.stringify(backup.admissions));
    }
    if (backup.custom_doctors) {
      localStorage.setItem('custom_doctors', JSON.stringify(backup.custom_doctors));
    }
    if (backup.custom_referred_doctors) {
      localStorage.setItem('custom_referred_doctors', JSON.stringify(backup.custom_referred_doctors));
    }
  };

  // 5. Direct navigation with pre-loaded patient from directory list
  const handleDirectAction = (tab: string, patient: Patient) => {
    setDirectPatient(patient);
    setActiveTab(tab);
  };

  // 6. Bulk sync all local states to Google Sheets
  const handleSyncAll = async () => {
    if (!token || !syncStatus.spreadsheetId) return;
    setSyncStatus(prev => ({ ...prev, isSyncing: true, error: null }));
    try {
      // Form row matrix for each data collection
      
      // A. Patients
      const patientRows = [
        ['Patient ID', 'Name', 'Phone', 'Age', 'Gender', 'Blood Group', 'Address', 'Initial Complaint', 'Created At'],
        ...patients.map(p => [p.id, p.name, p.phone, p.age, p.gender, p.bloodGroup, p.address, p.initialComplaint, p.createdAt])
      ];

      // B. Appointments
      const appointmentRows = [
        ['Appointment ID', 'Serial No', 'Patient Name', 'Patient Phone', 'Doctor Name', 'Specialty', 'Date', 'Time', 'Status'],
        ...appointments.map(a => [a.id, a.serialNo, a.patientName, a.patientPhone, a.doctorName, a.specialty, a.date, a.time, a.status])
      ];

      // C. Billing Invoices
      const invoiceRows = [
        ['Invoice ID', 'Patient Name', 'Patient Phone', 'Tests', 'Sub Total (৳)', 'Discount (৳)', 'Net Total (৳)', 'Amount Paid (৳)', 'Due Amount (৳)', 'Payment Status', 'Created At'],
        ...invoices.map(i => [
          i.id,
          i.patientName,
          i.patientPhone,
          i.tests.map(t => `${t.name}(৳${t.cost})`).join(', '),
          i.subTotal,
          i.discount,
          i.total,
          i.amountPaid,
          i.dueAmount,
          i.status,
          i.createdAt
        ])
      ];

      // D. Prescriptions
      const prescriptionRows = [
        ['Prescription ID', 'Patient Name', 'Patient Age', 'Patient Gender', 'BP', 'Temperature (°F)', 'Weight (KG)', 'Pulse', 'Symptoms', 'Diagnosis', 'Medicines', 'Advice', 'Created At'],
        ...prescriptions.map(p => [
          p.id,
          p.patientName,
          p.patientAge,
          p.patientGender,
          p.vitals.bp,
          p.vitals.temp,
          p.vitals.weight,
          p.vitals.pulse,
          p.symptoms,
          p.diagnosis,
          p.medicines.map(m => `${m.name} - ${m.dosage} (${m.instruction} / ${m.duration})`).join(' | '),
          p.advice,
          p.createdAt
        ])
      ];

      // E. Admissions
      const admissionRows = [
        ['Admission ID', 'Patient ID', 'Patient Name', 'Phone', 'Age', 'Sex', 'Reg No', 'Cabin/Bed', 'Father/Husband', 'Mother', 'Religion', 'Occupation', 'Admission Date/Time', 'Created At'],
        ...admissions.map(adm => [
          adm.id,
          adm.patientId,
          adm.patientName,
          adm.patientPhone,
          adm.patientAge,
          adm.patientGender,
          adm.regNo,
          adm.cabinWardBedNo,
          adm.fathersHusbandsName,
          adm.mothersName,
          adm.religion,
          adm.occupation,
          adm.admissionDateTime,
          adm.createdAt
        ])
      ];

      // Write sequence
      await writeSheetData(syncStatus.spreadsheetId, 'Patients', patientRows, token);
      await writeSheetData(syncStatus.spreadsheetId, 'Appointments', appointmentRows, token);
      await writeSheetData(syncStatus.spreadsheetId, 'DiagnosticTests', invoiceRows, token);
      await writeSheetData(syncStatus.spreadsheetId, 'Prescriptions', prescriptionRows, token);
      await writeSheetData(syncStatus.spreadsheetId, 'Admissions', admissionRows, token);

      const timestamp = new Date().toLocaleString('bn-BD');
      setSyncStatus(prev => ({
        ...prev,
        lastSynced: timestamp,
        isSyncing: false,
        error: null,
      }));
      localStorage.setItem('hms_last_synced', timestamp);
      alert('All data synced successfully to Google Sheets!');
    } catch (err: any) {
      console.error(err);
      setSyncStatus(prev => ({ ...prev, isSyncing: false, error: 'Could not upload data to Google Sheets. Token might have expired.' }));
    }
  };

  const appStyle = {
    fontFamily: globalSettings.selectedFont === 'system-ui' ? 'sans-serif' : `"${globalSettings.selectedFont}", sans-serif`,
    fontSize: globalSettings.fontSizeMultiplier === 'Small'
      ? '0.88rem'
      : globalSettings.fontSizeMultiplier === 'Large'
        ? '1.08rem'
        : '0.96rem'
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col antialiased text-slate-800 transition-all" style={appStyle}>
      
      {/* Top Header letterhead banner */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40" id="main-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-600 p-2.5 rounded-xl text-white shadow-sm flex items-center justify-center">
              <Heart className="w-6 h-6 animate-pulse fill-white" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold text-slate-900 tracking-tight flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2">
                <span>{globalSettings.institutionName}</span>
                <span className="text-xs font-semibold text-slate-500 font-mono">{globalSettings.englishName}</span>
              </h1>
              <p className="text-xs text-slate-500 font-medium">{globalSettings.address} | Helpline: {globalSettings.phone}</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {syncStatus.spreadsheetId && user && (
              <button
                onClick={handleSyncAll}
                disabled={syncStatus.isSyncing}
                title="Sync all data to Google Sheets"
                className="flex items-center gap-1.5 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 disabled:bg-slate-100 text-emerald-700 hover:text-emerald-800 rounded-xl text-xs font-bold border border-emerald-100 transition-all cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${syncStatus.isSyncing ? 'animate-spin' : ''}`} />
                {syncStatus.isSyncing ? 'Syncing...' : 'Sync to Sheets'}
              </button>
            )}

            {user ? (
              <div className="flex items-center gap-2">
                {user.photoURL && (
                  <img src={user.photoURL} alt={user.displayName || ''} className="w-8 h-8 rounded-full border border-slate-200 shadow-xs" referrerPolicy="no-referrer" />
                )}
                <button
                  onClick={handleLogout}
                  title="Logout"
                  className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition-all cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : null}
          </div>
        </div>
      </header>

      {/* Main Body content with Side Bar Tabs or Top Bar Navigation */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 flex-1 flex flex-col md:flex-row gap-6">
        
        {/* Navigation Sidebar panel */}
        <aside className="w-full md:w-64 shrink-0 flex flex-col gap-2 bg-white rounded-2xl p-4 border border-slate-100 shadow-xs md:sticky md:top-24 max-h-[calc(100vh-120px)] overflow-y-auto" id="sidebar-navigation">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 mb-1">Main Navigation</span>
          
          <button
            onClick={() => { setActiveTab('dashboard'); setDirectPatient(null); }}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'dashboard'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <Activity className="w-4 h-4" />
            Dashboard Overview
          </button>

          <button
            onClick={() => { setActiveTab('patients'); setDirectPatient(null); }}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'patients'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            Registered Patients ({patients.length})
          </button>

          <button
            onClick={() => { setActiveTab('appointments'); }}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'appointments'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <Calendar className="w-4 h-4" />
            Doctor Schedule
          </button>

          <button
            onClick={() => { setActiveTab('billing'); }}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'billing'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <Receipt className="w-4 h-4" />
            Diagnostic Billing ({invoices.length})
          </button>

          <button
            onClick={() => { setActiveTab('prescription'); }}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'prescription'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <Clipboard className="w-4 h-4" />
            AI Prescriptions ({prescriptions.length})
          </button>

          <button
            onClick={() => { setActiveTab('admission'); }}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'admission'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <Hospital className="w-4 h-4" />
            Indoor Admission ({admissions.length})
          </button>

          <button
            onClick={() => { setActiveTab('payroll'); }}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'payroll'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            Staff & Payroll ({staff.length})
          </button>

          <div className="border-t border-slate-100 my-2"></div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 mb-1">Connection Settings</span>

          <button
            onClick={() => { setActiveTab('sync'); setDirectPatient(null); }}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'sync'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <Database className="w-4 h-4" />
            Google Sheets Sync
            {syncStatus.spreadsheetId && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 ml-auto animate-pulse"></span>
            )}
          </button>

          <button
            onClick={() => { setActiveTab('settings'); setDirectPatient(null); }}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'settings'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <Settings className="w-4 h-4 text-amber-500" />
            Settings & Control Panel
          </button>
        </aside>

        {/* Dynamic Display Area based on selected Tab */}
        <main className="flex-1 min-w-0">
          {activeTab === 'dashboard' && (
            <Dashboard
              patients={patients}
              appointments={appointments}
              invoices={invoices}
              onSelectTab={setActiveTab}
              onRestoreData={handleRestoreData}
            />
          )}

          {activeTab === 'patients' && (
            <PatientManagement
              patients={patients}
              onAddPatient={handleAddPatient}
              onUpdatePatient={handleUpdatePatient}
              onDeletePatient={handleDeletePatient}
              onDirectAction={handleDirectAction}
            />
          )}

          {activeTab === 'appointments' && (
            <AppointmentManagement
              appointments={appointments}
              patients={patients}
              onAddAppointment={handleAddAppointment}
              onUpdateStatus={handleUpdateAppointmentStatus}
              selectedPatientFromDirectAction={directPatient}
              clearDirectPatient={() => setDirectPatient(null)}
            />
          )}

          {activeTab === 'billing' && (
            <BillingManagement
              invoices={invoices}
              patients={patients}
              onAddInvoice={handleAddInvoice}
              onAddPatient={handleAddPatient}
              onUpdatePayment={handleUpdatePayment}
              onUpdateCommissionStatus={handleUpdateCommissionStatus}
              selectedPatientFromDirectAction={directPatient}
              clearDirectPatient={() => setDirectPatient(null)}
              diagnosticTests={diagnosticTests}
            />
          )}

          {activeTab === 'prescription' && (
            <PrescriptionGenerator
              prescriptions={prescriptions}
              patients={patients}
              onAddPrescription={handleAddPrescription}
              selectedPatientFromDirectAction={directPatient}
              clearDirectPatient={() => setDirectPatient(null)}
            />
          )}

          {activeTab === 'admission' && (
            <IndoorAdmissionComponent
              admissions={admissions}
              patients={patients}
              onAddAdmission={handleAddAdmission}
              onUpdateAdmission={handleUpdateAdmission}
              onDeleteAdmission={handleDeleteAdmission}
              selectedPatientFromDirectAction={directPatient}
              clearDirectPatient={() => setDirectPatient(null)}
            />
          )}

          {activeTab === 'payroll' && (
            <StaffPayrollManagement
              staff={staff}
              transactions={staffTransactions}
              onAddStaff={(newStaff) => setStaff(prev => [...prev, newStaff])}
              onDeleteStaff={(id, name) => {
                if (window.confirm(`Are you sure you want to remove ${name}?`)) {
                  setStaff(prev => prev.filter(s => s.id !== id));
                }
              }}
              onUpdateStaffList={setStaff}
              onAddTransaction={(newTrans) => setStaffTransactions(prev => [newTrans, ...prev])}
            />
          )}

          {activeTab === 'sync' && (
            <SheetsSync
              user={user}
              token={token}
              onLogin={handleLoginSuccess}
              onLogout={handleLogout}
              syncStatus={syncStatus}
              setSyncStatus={setSyncStatus}
              onSyncAll={handleSyncAll}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsManagement
              invoices={invoices}
              admissions={admissions}
              diagnosticTests={diagnosticTests}
              onUpdateTests={setDiagnosticTests}
              globalSettings={globalSettings}
              onUpdateSettings={setGlobalSettings}
              staff={staff}
              setStaff={setStaff}
              transactions={staffTransactions}
              setTransactions={setStaffTransactions}
            />
          )}
        </main>
      </div>

      {/* Footer credits panel */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-400 mt-auto" id="main-footer">
        <p>© {new Date().getFullYear()} {globalSettings.institutionName} ({globalSettings.englishName}). All rights reserved.</p>
        <p className="mt-1 flex items-center justify-center gap-1">
          Google Sheets & Cloud Data Security Integrated
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 fill-emerald-50" />
        </p>
      </footer>
    </div>
  );
}
