export interface Patient {
  id: string;
  name: string;
  phone: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  bloodGroup: string;
  address: string;
  initialComplaint: string;
  createdAt: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  doctorName: string;
  specialty: string;
  date: string;
  time: string;
  status: 'Pending' | 'Completed' | 'Cancelled';
  serialNo: number;
}

export interface DiagnosticTest {
  name: string;
  cost: number;
}

export interface BillingInvoice {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  tests: DiagnosticTest[];
  subTotal: number;
  discount: number;
  total: number;
  amountPaid: number;
  dueAmount: number;
  status: 'Paid' | 'Due' | 'Partial';
  createdAt: string;
  referredDoctor?: string;
  patientAge?: number;
  patientGender?: string;
  patientBloodGroup?: string;
  patientAddress?: string;
  commissionType?: 'percent' | 'flat';
  commissionValue?: number;
  commissionAmount?: number;
  commissionPaidStatus?: 'Paid' | 'Unpaid';
}

export interface Prescription {
  id: string;
  patientId: string;
  patientName: string;
  patientAge: number;
  patientGender: string;
  vitals: {
    bp: string;
    temp: string;
    weight: string;
    pulse: string;
  };
  symptoms: string;
  diagnosis: string;
  medicines: {
    name: string;
    dosage: string; // e.g. "1+0+1"
    instruction: string; // e.g. "খাবারের আগে" or "খাবারের পর"
    duration: string; // e.g. "৭ দিন"
  }[];
  advice: string;
  doctorName?: string;
  doctorDegrees?: string;
  doctorSpecialty?: string;
  doctorDesignation?: string;
  doctorBmdc?: string;
  createdAt: string;
}

export interface SyncStatus {
  spreadsheetId: string | null;
  spreadsheetUrl: string | null;
  lastSynced: string | null;
  isSyncing: boolean;
  error: string | null;
}

export interface IndoorAdmission {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  patientAge: number;
  patientGender: string;
  
  // Admission Form Fields
  regNo: string;
  cabinWardBedNo: string;
  fathersHusbandsName: string;
  mothersName: string;
  religion: string;
  occupation: string;
  nationality: string;
  guardianName: string;
  relation: string;
  guardianOccupation: string;
  guardianNationality: string;
  presentAddress: string;
  permanentAddress: string;
  admissionDateTime: string;
  orderOfDoctor: string;

  // Consent Form Fields
  doctorName: string;
  anaesthetistName: string;
  consentWitnessName: string;
  consentWitnessRelation: string;
  consentWitnessAddress: string;
  consentDate: string;

  // Post Operative Order Fields
  opDate: string;
  opIndication: string;
  opName: string;
  opAnaesthesia: string;
  opOutcome: string;
  opSurgeon: string;
  opAnaesthetist: string;
  opAssistants: string;
  
  // Rx selections
  rxItems: {
    id: number;
    checked: boolean;
    val1?: string;
    val2?: string;
    val3?: string;
  }[];
  
  // Discharge Fields
  status?: 'Admitted' | 'Discharged';
  dischargeDateTime?: string;
  dischargeCondition?: string;
  dischargeAdvice?: string;
  dischargeMedicines?: {
    name: string;
    dosage: string;
    instruction: string;
    duration: string;
  }[];
  followUpDate?: string;
  
  // Discharge Bill Fields
  dischargeCabinCharge?: number;
  dischargeCabinDays?: number;
  dischargeDoctorFee?: number;
  dischargeOpFee?: number;
  dischargeOtCharge?: number;
  dischargeAnaesthetistFee?: number;
  dischargeMedicineCharge?: number;
  dischargeOtherCharge?: number;
  dischargeBillSubtotal?: number;
  dischargeBillDiscount?: number;
  dischargeBillTotal?: number;
  dischargeBillPaid?: number;
  dischargeBillDue?: number;
  
  createdAt: string;
}

export const STAFF_ROLES: { [key: string]: string } = {
  Admin: 'Admin',
  Doctor: 'Doctor',
  Nurse: 'Nurse',
  MedicalAssistant: 'Medical Assistant',
  MTLab: 'MT Lab / Technologist',
  MTRadiographer: 'MT Radiographer',
  OTBoy: 'OT Boy / Assistant',
  Aya: 'Ward Attendant / Aya',
  WardBoy: 'Ward Boy / Assistant',
  Pharmacist: 'Pharmacist',
  Receptionist: 'Receptionist',
  Accountant: 'Accountant',
  Cleaner: 'Cleaner / Sweeper',
  Security: 'Security Guard',
  Driver: 'Driver / Ambulance Driver',
  Staff: 'Other Staff'
};

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  salary: number;
  advance: number;
  due: number;
  createdAt: string;
}

export interface StaffTransaction {
  id: string;
  staffId: string;
  staffName: string;
  type: 'Salary' | 'Advance' | 'DueAdjustment';
  amount: number;
  date: string;
  note: string;
}

export interface DailyExpense {
  id: string;
  title: string;
  category: string;
  amount: number;
  date: string;
  description: string;
}

export interface GlobalSettings {
  institutionName: string;
  englishName: string;
  phone: string;
  address: string;
  selectedFont: 'Hind Siliguri' | 'Inter' | 'system-ui';
  fontSizeMultiplier: 'Small' | 'Normal' | 'Large';
  defaultAdmissionFee: number;
  defaultDoctorFee: number;
}


