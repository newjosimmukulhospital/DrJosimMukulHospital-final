export interface DoctorProfile {
  id: string;
  nameBn: string;
  nameEn: string;
  degreesBn: string;
  degreesEn: string;
  specialtyBn: string;
  specialtyEn: string;
  designationBn?: string;
  designationEn?: string;
  bmdcBn?: string;
  bmdcEn?: string;
  chamberBn: string;
  chamberEn: string;
}

export const DOCTORS: DoctorProfile[] = [
  {
    id: 'mukul',
    nameBn: 'ডাঃ মুঃ জসিম উদ্দিন (মুকুল)',
    nameEn: 'Dr. Muh. Jasim Uddin (Mukul)',
    degreesBn: 'এম.বি.বি.এস (ঢাকা)',
    degreesEn: 'MBBS (Dhaka)',
    specialtyBn: 'স্ত্রী ও ধাত্রী বিদ্যায় অভিজ্ঞ ও সার্জন এবং সনোলজিষ্ট',
    specialtyEn: 'Experienced in Gynecology & Obstetrics, Surgeon and Sonologist',
    designationBn: 'ডাঃ জসিম মুকুল হাসপাতাল, গলাচিপা',
    designationEn: 'Dr. Jasim Mukul Hospital, Galachipa',
    chamberBn: 'শনি, সোম, বুধবার সকাল ৯.০০টা থেকে দুপুর ৩.০০টা পর্যন্ত',
    chamberEn: 'Sat, Mon, Wed (9:00 AM to 3:00 PM)',
  },
  {
    id: 'mahmud',
    nameBn: 'ডাঃ মোঃ সুলতান মাহমুদ',
    nameEn: 'Dr. Md. Sultan Mahmud',
    degreesBn: 'এম.বি.বি.এস, বিসিএস (স্বাস্থ্য), এফসিপিএস (সার্জারী)',
    degreesEn: 'MBBS, BCS (Health), FCPS (Surgery)',
    specialtyBn: 'জেনারেল ল্যাপারোস্কোপিক ও কোলোরেক্টাল সার্জন',
    specialtyEn: 'General, Laparoscopic & Colorectal Surgeon',
    designationBn: 'সহকারী অধ্যাপক (সার্জারী), পটুয়াখালী মেডিকেল কলেজ, পটুয়াখালী',
    designationEn: 'Assistant Professor (Surgery), Patuakhali Medical College, Patuakhali',
    bmdcBn: 'বিএমডিসি রেজিঃ নং-A-372287',
    bmdcEn: 'BMDC Reg No: A-372287',
    chamberBn: 'শনিবার দুপুর ২টা থেকে বিকাল ৫টা পর্যন্ত',
    chamberEn: 'Saturday (2:00 PM to 5:00 PM)',
  },
  {
    id: 'ahmed',
    nameBn: 'ডাঃ জহির উদ্দিন আহমেদ',
    nameEn: 'Dr. Jahir Uddin Ahmed',
    degreesBn: 'এম.বি.বি.এস, (চ.বি), ডি.ও (ঢা.বি), আই.সি.ও (ইংল্যান্ড)',
    degreesEn: 'MBBS (CU), DO (DU), ICO (England)',
    specialtyBn: 'প্রাক্তন চক্ষু বিশেষজ্ঞ, সৌদি স্বাস্থ্য মন্ত্রণালয়, সৌদি আরব',
    specialtyEn: 'Ophthalmologist (Eye Specialist)',
    designationBn: 'প্রাক্তন সহযোগী অধ্যাপক, খাজা ইউনুস আলী মেডিকেল কলেজ হাসপাতাল, এনায়েতপুর, সিরাজগঞ্জ',
    designationEn: 'Former Associate Professor, Khwaja Yunus Ali Medical College Hospital, Sirajganj | Former Eye Specialist, Ministry of Health, Saudi Arabia',
    bmdcBn: 'বি.এম.ডি.সি রেজিঃ নং-৮০৭০',
    bmdcEn: 'BMDC Reg No: 8070',
    chamberBn: 'প্রতি মঙ্গলবার সকাল ১০টা থেকে রাত ৯টা পর্যন্ত',
    chamberEn: 'Tuesday (10:00 AM to 9:00 PM)',
  },
  {
    id: 'sohag',
    nameBn: 'ডাঃ রায়হান সোহাগ',
    nameEn: 'Dr. Rayhan Sohag',
    degreesBn: 'এমবিবিএস (ঢাকা), এমপিএইচ (মা, শিশু ও কিশোর স্বাস্থ্য)',
    degreesEn: 'MBBS (Dhaka), MPH (Maternal, Child & Adolescent Health)',
    specialtyBn: 'জনস্বাস্থ্য বিশেষজ্ঞ ও মেডিকেল অফিসার (প্রাক্তন)',
    specialtyEn: 'Public Health Specialist & General Practitioner',
    designationBn: 'প্রশিক্ষণ প্রাপ্ত: সিসিডি (বারডেম), এমসিজিপি (মেডিসিন), ডিএমইউ (আল্ট্রা), পিজিটি (নবজাতক ও শিশু), সিটিএম (থাইরয়েড মেডিসিন), আইএমসিআই (ঢাকা শিশু হাসপাতাল)। পটুয়াখালী মেডিকেল কলেজ হাসপাতাল',
    designationEn: 'Former Medical Officer, Patuakhali Medical College Hospital | Trained in CCD (BIRDEM), MCGP (Medicine), DMU (Ultra), PGT (Pediatrics), CTM (Thyroid Medicine), IMCI (Dhaka Shishu Hospital)',
    bmdcBn: 'বিএমডিসি রেজিঃ নং-A-69895',
    bmdcEn: 'BMDC Reg No: A-69895',
    chamberBn: 'প্রতি রবি, মঙ্গল, বৃহস্পতি ও শুক্রবার সকাল ১০টা - দুপুর ২টা এবং বিকাল ৫টা - রাত ৯টা',
    chamberEn: 'Sun, Tue, Thu & Fri (10:00 AM - 2:00 PM & 5:00 PM - 9:00 PM)',
  },
  {
    id: 'zaman',
    nameBn: 'ডাঃ রানী জামান',
    nameEn: 'Dr. Rani Zaman',
    degreesBn: 'এম.বি.বি.এস (ঢাকা)',
    degreesEn: 'MBBS (Dhaka)',
    specialtyBn: 'গাইনী ও স্ত্রী রোগ বিশেষজ্ঞ',
    specialtyEn: 'General Practitioner (Experienced in Gynecology & Obstetrics)',
    designationBn: 'প্রশিক্ষণ প্রাপ্ত: ডি.এম.ইউ (আল্ট্রা), বিএফএইচআই (এনএনএস), পিজিটি (গাইনী এন্ড অবস), মেডিকেল অফিসার (প্রাক্তন), ২৫০ শয্যা বিশিষ্ট হাসপাতাল, পটুয়াখালী',
    designationEn: 'Former Medical Officer, 250 Bed General Hospital, Patuakhali | Trained in DMU (Ultra), BFHI (NNS), PGT (Gynae & Obs)',
    bmdcBn: 'বিএমডিসি রেজিঃ নং-A-69894',
    bmdcEn: 'BMDC Reg No: A-69894',
    chamberBn: 'প্রতি রবি থেকে শুক্রবার সকাল ৯টা থেকে দুপুর ২টা এবং বিকাল ৫টা থেকে রাত ৯টা পর্যন্ত',
    chamberEn: 'Sun to Fri (9:00 AM - 2:00 PM & 5:00 PM - 9:00 PM)',
  }
];

export const HOSPITAL_INFO = {
  nameBn: 'ডাঃ জসিম মুকুল হাসপাতাল',
  nameEn: 'DR. JASIM MUKUL HOSPITAL',
  addressBn: '২১৪/১ ভি আই পি রোড (ইউএনও অফিসের পশ্চিম পার্শ্বে), গলাচিপা, পটুয়াখালী',
  addressEn: '214/1 V.I.P. Road (West side of UNO Office), Galachipa, Patuakhali',
  phone: '০১৭৭৮-০৭০৫০৮' // Typical phone placeholder or empty
};

export const getDoctors = (): DoctorProfile[] => {
  if (typeof window !== 'undefined') {
    const saved = window.localStorage.getItem('custom_doctors');
    if (saved) {
      try {
        const custom: DoctorProfile[] = JSON.parse(saved);
        return [...DOCTORS, ...custom];
      } catch (e) {
        console.error('Failed to parse custom doctors', e);
      }
    }
  }
  return DOCTORS;
};

export const addCustomDoctor = (doc: Omit<DoctorProfile, 'id'>): DoctorProfile | null => {
  if (typeof window !== 'undefined') {
    const newDoc: DoctorProfile = {
      ...doc,
      id: 'custom_' + Date.now(),
    };
    const saved = window.localStorage.getItem('custom_doctors');
    let custom: DoctorProfile[] = [];
    if (saved) {
      try {
        custom = JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse existing custom doctors', e);
      }
    }
    const updatedCustom = [...custom, newDoc];
    window.localStorage.setItem('custom_doctors', JSON.stringify(updatedCustom));
    return newDoc;
  }
  return null;
};

